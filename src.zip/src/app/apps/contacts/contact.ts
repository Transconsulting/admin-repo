export class Contact {
     firstName = '';
     lastName = '';

     mobile = '';
     home = '';
     company = '';
     work = '';
     notes = '';
     imagePath = '';
}
