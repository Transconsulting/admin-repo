export class Contact {
     id=0;
     firstName = '';
     lastName = '';
     mobile = '';
     home = '';
     company = '';
     work = '';
     notes = '';
     imagePath = '';
}
