import { Contact } from './contact';

export const contacts: Contact[] = [
    {
        id:1,
        firstName: 'Raj',
        lastName: 'Dev',
        mobile: '979797992',
        home: 'jodhpur',
        company: ' F creation',
        work: 'AD',
        notes: ' i  qb   inujjbw.',
        imagePath: 'assets/images/users/user5.jpg'
    },
    {
        id:2,
        firstName: 'Mark',
        lastName: 'Smith',
        mobile: '989797772',
        home: 'Rajasthan',
        company: ' F creation',
        work: 'Designer',
        notes: '  noyes kns  nal  sjj  s  slhjal.',
        imagePath: 'assets/images/users/user2.jpg'
    },
    {
        id:3,
        firstName: 'Jony',
        lastName: 'Deep',
        mobile: '9234567563',
        home: 'LA',
        company: ' F creation',
        work: 'Admin',
        notes: ' admin : baun ja ayu gsiko iaij sikioa...',
        imagePath: 'assets/images/users/user3.jpg'
    },
    {
        id:4,
        firstName: 'Leonardo',
        lastName: 'Caprio',
        mobile: '7837937777',
        home: 'NJ',
        company: ' F creation',
        work: 'ADMIN',
        notes: 'Leo nah ujhakj jjj akkak asdkfga an a .',
        imagePath: 'assets/images/users/user4.jpg'
    }
];
