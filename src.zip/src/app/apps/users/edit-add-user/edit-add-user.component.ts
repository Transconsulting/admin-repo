import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-add-user',
  templateUrl: './edit-add-user.component.html',
  styleUrls: ['./edit-add-user.component.css']
})
export class EditAddUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
