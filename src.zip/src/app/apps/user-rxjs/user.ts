export class User {
  public id = 0;
  public Name = '';
  public Position = '';
  public Email = '';
  public Mobile = 0;
  public DateOfJoining: Date | null = null;
  public Salary = 0;
  public Projects = 0;
  public imagePath = '';
}