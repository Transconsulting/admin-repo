export class Note {
    color = '';
    title = '';
    datef: Date | null = null;
}

