export class TaskSection {
    public Id = 202;
    public status = false;

    public title = '';

    public priority = '';
    public dueDate = '';
    public notes = '';

    public border = false;

    public sectionTaskType = '';

}
