export class Ticket {
    Id = 0;
    Status: string | null = null;
    Label: string | null = null;
    ticketTitle: string | null = null;
    ticketDescription: string | null = null;
    AgentName: string | null = null;
    Date: Date | null = null;
}
