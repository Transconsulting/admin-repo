import { Component } from '@angular/core';
@Component({
  selector: 'app-earning-report',
  templateUrl: './earning-report.component.html'
})
export class EarningComponent {
  constructor() {}
}
