import { Component } from '@angular/core';
@Component({
  selector: 'app-social-slider',
  templateUrl: './social-slider.component.html'
})
export class SocialSliderComponent {
  constructor() {}
}
