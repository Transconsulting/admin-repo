import { Component } from '@angular/core';
@Component({
  selector: 'app-browser',
  templateUrl: './browser.component.html'
})
export class BrowserComponent {
  constructor() { }
}
