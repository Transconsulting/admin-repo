import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paiement-form',
  templateUrl: './paiement-form.component.html',
  styleUrls: ['./paiement-form.component.scss']
})
export class PaiementFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
