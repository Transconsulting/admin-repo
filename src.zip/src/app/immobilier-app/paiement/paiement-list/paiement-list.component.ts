import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paiement-list',
  templateUrl: './paiement-list.component.html',
  styleUrls: ['./paiement-list.component.scss']
})
export class PaiementListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
