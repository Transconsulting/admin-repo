import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parcelle-appartement-list',
  templateUrl: './parcelle-appartement-list.component.html',
  styleUrls: ['./parcelle-appartement-list.component.scss']
})
export class ParcelleAppartementListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
