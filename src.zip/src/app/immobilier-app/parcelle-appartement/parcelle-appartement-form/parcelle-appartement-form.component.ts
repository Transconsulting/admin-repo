import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parcelle-appartement-form',
  templateUrl: './parcelle-appartement-form.component.html',
  styleUrls: ['./parcelle-appartement-form.component.scss']
})
export class ParcelleAppartementFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
