import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contrat-form',
  templateUrl: './contrat-form.component.html',
  styleUrls: ['./contrat-form.component.scss']
})
export class ContratFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
