import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contrat-list',
  templateUrl: './contrat-list.component.html',
  styleUrls: ['./contrat-list.component.scss']
})
export class ContratListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
