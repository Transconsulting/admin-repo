import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-details-parcelle-appartement-form',
  templateUrl: './details-parcelle-appartement-form.component.html',
  styleUrls: ['./details-parcelle-appartement-form.component.scss']
})
export class DetailsParcelleAppartementFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
