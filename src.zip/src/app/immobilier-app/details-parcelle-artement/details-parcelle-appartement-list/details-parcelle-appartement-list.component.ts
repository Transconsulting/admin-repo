import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-details-parcelle-appartement-list',
  templateUrl: './details-parcelle-appartement-list.component.html',
  styleUrls: ['./details-parcelle-appartement-list.component.scss']
})
export class DetailsParcelleAppartementListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
